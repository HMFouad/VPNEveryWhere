#!/usr/bin/env python
  
# exemple barreprogression.py

import pygtk
pygtk.require('2.0')
import gtk

# Fonction qui actualise la valeur de la barre de progression
# pour qu'on ait un petit peu de mouvement
def tempo_progression(objetbarre):
        objetbarre.barreprogression.pulse()
   
        # On calcule la valeur de la barre de progression en prenant
        # en compte l'intervalle defini dans l'ajustement
        nouv_val = objetbarre.barreprogression.get_fraction() + 0.001
        if nouv_val > 1.0:
            nouv_val = 1
        # On fixe la nouvelle valeur
        objetbarre.barreprogression.set_fraction(nouv_val)

    # Cette fonction etant une fonction de temporisation, on
    # renvoie TRUE afin qu'elle puisse encore etre appelee
        return True

class BarreProgression:
    # Liberation de la memoire reservee et retrait de la temporisation
    def sortie(self, widget, data=None):
        gtk.timeout_remove(self.tempo)
        self.tempo = 0
        gtk.main_quit()

    def __init__(self):
        self.Frame = gtk.Window(gtk.WINDOW_TOPLEVEL)
        self.Frame.set_resizable(True)

        self.Frame.connect("destroy", self.sortie)
        self.Frame.set_title("Barre de progression")
        self.Frame.set_border_width(0)

        boite_v = gtk.VBox(False, 50)
        boite_v.set_border_width(100)
        self.Frame.add(boite_v)
        boite_v.show()
  
        # Creation d'un objet alignement au centre
        align = gtk.Alignment(0.5, 0.5, 0, 0)
        boite_v.pack_start(align, False, False, 50)
        align.show()

        # Creation de la barre de progression en utilisant l'ajustement
        self.barreprogression = gtk.ProgressBar()

        align.add(self.barreprogression)
        self.barreprogression.show()

        # On ajoute une fonction de rappel temporisee, qui actualisera
        # la valeur de la barre de progression
        self.tempo = gtk.timeout_add (100, tempo_progression, self)




        self.Frame.show()

def main():
    gtk.main()
    return 0

if __name__ == "__main__":
    BarreProgression()
    main()
